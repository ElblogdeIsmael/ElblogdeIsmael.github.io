/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.ArrayList;

/**
 * La clase {@code Player} representa a un jugador en el juego, que posee atributos de
 * inteligencia, fuerza, salud, y una posición en el laberinto. Además, puede equiparse
 * con armas y escudos, atacar y defenderse en el juego.
 * <p>
 * Cada jugador tiene límites en la cantidad de armas y escudos que puede llevar,
 * y también puede resucitar o recibir recompensas durante el juego.
 * </p>
 * 
 * <p> Contiene métodos para mover al jugador, atacar, defender, y recibir heridas.
 * Los jugadores interactúan con otros objetos del juego, como el dado y los elementos
 * de combate, para determinar su rendimiento en el juego.</p>
 * 
 * Atributos de la clase:
 * <ul>
 * <li><b>MAX_WEAPONS:</b> El número máximo de armas que puede llevar el jugador (valor por defecto: 2).</li>
 * <li><b>MAX_SHIELDS:</b> El número máximo de escudos que puede llevar el jugador (valor por defecto: 3).</li>
 * <li><b>INITIAL_HEALTH:</b> La salud inicial del jugador al comenzar el juego (valor por defecto: 10).</li>
 * <li><b>HITS2LOSE:</b> El número de golpes que el jugador puede recibir antes de perder (valor por defecto: 3).</li>
 * <li><b>name:</b> El nombre del jugador.</li>
 * <li><b>number:</b> Un identificador único para el jugador, representado como un carácter.</li>
 * <li><b>intelligence:</b> El nivel de inteligencia del jugador, afectando su desempeño en el juego.</li>
 * <li><b>strength:</b> El nivel de fuerza del jugador, que influye en su capacidad de ataque.</li>
 * <li><b>health:</b> La salud actual del jugador, que disminuye al recibir daño.</li>
 * <li><b>row:</b> La posición de fila del jugador en el laberinto.</li>
 * <li><b>col:</b> La posición de columna del jugador en el laberinto.</li>
 * <li><b>consecutiveHits:</b> Contador de los golpes consecutivos recibidos por el jugador.</li>
 * <li><b>weapons:</b> Lista de armas que posee el jugador.</li>
 * <li><b>shields:</b> Lista de escudos que posee el jugador.</li>
 * </ul>
 * 
 * @author ismael
 */
public class Player {
    private final int MAX_WEAPONS = 2;
    private final int MAX_SHIELDS = 3;
    private final int INITIAL_HEALTH = 10;
    private final int HITS2LOSE = 3;

    private String name;
    private char number;
    private float intelligence;
    private float strength;
    private int health;
    private int row;
    private int col;
    private int consecutiveHits = 0;
    private ArrayList<Weapon> weapons;
    private ArrayList<Shield> shields;

    /**
     * Constructor para la clase {@code Player}.
     * @param number Identificador del jugador.
     * @param intelligence Nivel de inteligencia del jugador.
     * @param strength Nivel de fuerza del jugador.
     * @param health Nivel de salud del jugador.
     */
    public Player(char number, float intelligence, float strength) {
        this.name = "Player #"+number;
        this.number = number;
        this.intelligence = intelligence;
        this.strength = strength;
        this.health = INITIAL_HEALTH;
        row=-1;
        col=-1;
        this.weapons = new ArrayList<>();
        this.shields = new ArrayList<>();
    }
    
    /**
     * Devuelve el nombre del jugador.
     * @return El nombre del jugador.
     */
    public String getName() {
        return name;
    }


    /**
     * Resucita al jugador restaurando su salud, hits consecutivos y reiniciando armas y escudos.
     */
    public void resurrect() {    
        health = INITIAL_HEALTH;
        consecutiveHits = 0;
        weapons = new ArrayList<>();  
        shields = new ArrayList<>();
    }

    /**
     * Obtiene la posición de fila del jugador.
     * @return La posición de la fila.
     */
    public int getRow() {
        return row;
    }

    /**
     * Obtiene la posición de columna del jugador.
     * @return La posición de la columna.
     */
    public int getCol() {
        return col;
    }

    /**
     * Obtiene el número identificador del jugador.
     * @return El número del jugador.
     */
    public char getNumber() {
        return (char)number;
    }

    /**
     * Establece la posición del jugador.
     * @param row La fila a establecer.
     * @param col La columna a establecer.
     */
    public void setPos(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * Verifica si el jugador está muerto.
     * @return {@code true} si la salud del jugador es 0 o menor; {@code false} en caso contrario.
     */
    public boolean dead() {
        return this.health <= 0;
    }

    /**
     * Calcula el poder de ataque del jugador, basado en su fuerza y el poder de sus armas.
     * @return El poder total de ataque.
     */
    public float attack() {
        return this.strength + sumWeapons();
    }

    /**
     * Defiende al jugador de un ataque recibido.
     * @param receivedAttack La potencia del ataque recibido.
     * @return {@code true} si el jugador se defiende exitosamente; {@code false} en caso contrario.
     */
    public boolean defend(float receivedAttack) {
        return manageHit(receivedAttack);
    }

    /**
     * Representación en cadena del jugador.
     * @return Una cadena con los detalles del jugador.
     */
    @Override
    public String toString() {
        String output;
        output = "Name: " + this.name + " Intelligence: " + this.intelligence + " Strength: " + this.strength + 
            " Health: " + this.health + " Position: " + this.row + "," + this.col +
            " Consecutive Hits: " + this.consecutiveHits + "\n";
        output+="\nWeapons: \n";
            for(Weapon w : weapons){
            output+=w.toString();
            output+="\n";
        }
        output+="\nShields: \n";
        for(Shield s : shields){
            output+=s.toString();
            output+="\n";
        }
        return output;
    }

    /**
     * Crea una nueva arma para el jugador.
     * @return Una nueva instancia de {@code Weapon}.
     */
    public Weapon newWeapon() {
        Weapon w = new Weapon(Dice.weaponPower(), Dice.usesLeft());
        return w;
    }

    /**
     * Crea un nuevo escudo para el jugador.
     * @return Una nueva instancia de {@code Shield}.
     */
    public Shield newShield() {
        Shield s = new Shield(Dice.shieldPower(), Dice.usesLeft());
        return s;
    }

    /**
     * Calcula la energía defensiva total de todos los escudos del jugador.
     * @return La energía defensiva acumulada.
     */
    public float defensiveEnergy() {
        return this.intelligence + sumShields();
    }

    /**
     * Reinicia el contador de golpes consecutivos recibidos.
     */
    public void resetHits() {
        this.consecutiveHits = 0;
    }

    /**
     * Reduce la salud del jugador en 1.
     */
    public void gotWounded() {
        this.health -= 1;
    }

    /**
     * Incrementa el contador de golpes consecutivos en 1.
     */
    public void incConsecutiveHits() {
        this.consecutiveHits++;
    }

    /**
     * Suma la potencia de ataque de todas las armas del jugador.
     * @return El poder total de ataque de todas las armas.
     */
    public float sumWeapons() {
        float sum = 0;
        for (Weapon w : weapons) {
            sum += w.attack();
        }
        return sum;
    }

    /**
     * Suma el poder defensivo de todos los escudos del jugador.
     * @return El poder total defensivo de todos los escudos.
     */
    public float sumShields() {
        float sum = 0;
        for (Shield s : shields) {
            sum += s.protect();
        }
        return sum;
    }

    /**
     * Mueve al jugador en una dirección dada.
     * @param direction La dirección en la que se moverá.
     * @param validMoves Los movimientos válidos disponibles.
     * @return La dirección en la que se movió el jugador.
     */
    public Directions move(Directions direction, Directions[] validMoves) {
        int size = validMoves.length;
        Directions firstElement;
        boolean contained = false;
        for(Directions d : validMoves){
            if(d==direction) contained=true;
        }
        if(size>0 && !contained){
            firstElement = validMoves[0];
        }
        else{
            firstElement=direction;
        }
        return firstElement;
    }

    /**
     * Recibe una recompensa.
     */
    public void receiveReward() {
        int wReward = Dice.weaponsReward();
        int sReward = Dice.shieldsReward();
        
        for(int i=0; i< wReward; i++){
            Weapon wnew = newWeapon();
            receiveWeapon(wnew);
        }
        for(int i=0; i< sReward; i++){
            Shield snew = newShield();
            receiveShield(snew);
        }
        int extraHealth = Dice.healthReward();
        this.health+=extraHealth;
        
    }
    
    /**
     * Recibe un arma y la agrega al inventario.
     * @param w El arma a recibir.
     */
    public void receiveWeapon(Weapon w) {
        for(int i=0;i<weapons.size();i++){
            Weapon wi = weapons.get(i);
            boolean discard = wi.discard();
            if(discard){
                weapons.remove(i);
            }
        }
        int size = weapons.size();
        if(size<MAX_WEAPONS){
            weapons.add(w);
        }
    }
    
    /**
     * Recibe un escudo y lo agrega al inventario.
     * @param s El escudo a recibir.
     */
    public void receiveShield(Shield s) {
        for(int i=0;i<shields.size();i++){
            Shield si = shields.get(i);
            boolean discard = si.discard();
            if(discard){
                shields.remove(i);
            }
            
        }
        int size = shields.size();
        if(size<MAX_SHIELDS){
            shields.add(s);
        }
    }
    
    /**
     * Gestiona el impacto de un ataque recibido por el jugador.
     * @param receivedAttack La potencia del ataque recibido.
     * @return {@code true} si el impacto fue gestionado exitosamente, {@code false} en caso contrario.
     */
    public boolean manageHit(float receivedAttack) {
        boolean lose=true;
        float defense=defensiveEnergy();
        if(defense<receivedAttack){
            gotWounded();
            incConsecutiveHits();
        }
        else{
            resetHits();
        }
        if(consecutiveHits==HITS2LOSE || dead()){
            resetHits();
            lose=true;
        }
        else {
            lose=false;
        }
        return lose;
        
    }
    /**
     * Añade una arma a weapons
     * @param w Arma a añadir
     */
    public void addWeapon(Weapon w) {
        weapons.add(w);
    }

    /**
     * Añade un escudo a shields
     * @param s Escudo a añadir
     */
    public void addShield(Shield s) {
        shields.add(s);
    }   
    

}
