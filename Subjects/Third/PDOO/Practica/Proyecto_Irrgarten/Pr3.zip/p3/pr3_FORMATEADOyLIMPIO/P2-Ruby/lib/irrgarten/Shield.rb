#encoding:utf-8
module Irrgarten
    # Clase que representa un escudo en el juego.
    # Un escudo tiene un nivel de protección y un número limitado de usos.
    class Shield
        attr_accessor :protection, :uses

        # Inicializa un nuevo escudo con un nivel de protección y usos.
        #
        # @param protection [Integer] Nivel de protección que ofrece el escudo.
        # @param uses [Integer] Número de veces que se puede usar el escudo.
        def initialize(protection, uses)
            @protection = protection
            @uses = uses
        end

        # Proporciona protección si el escudo tiene usos restantes. 
        # Decrementa los usos en 1 cada vez que se utiliza.
        #
        # @return [Integer] Nivel de protección si tiene usos restantes, 0 en caso contrario.
        def protect
            if @uses > 0
                @uses -= 1
                return @protection
            else
                return 0
            end
        end
        
        # Convierte el escudo a una representación en cadena.
        #
        # @return [String] Representación en cadena del escudo, formato "S[protection, uses]".
        def to_s    
            "S[#{@protection}, #{@uses}]"
        end

        # Verifica si el escudo debe ser descartado según el número de usos restantes.
        #
        # @return [Boolean] `true` si el escudo debe ser descartado, `false` en caso contrario.
        def discard
            Dice.discardElement(@uses)
        end
    end
end
