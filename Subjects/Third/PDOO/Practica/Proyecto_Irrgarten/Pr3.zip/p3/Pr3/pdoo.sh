#!/bin/bash

# Ruta de tu proyecto para abrir en Visual Studio Code
vscode_project="/home/ismael/Escritorio/3 de INFO-ADE 1semestre/PDOO/Github/p3/Pr3/p2-java
"
vscode_project2="/home/ismael/Escritorio/3 de INFO-ADE 1semestre/PDOO/interpretaciondeDiagramas"

# Ruta de tu proyecto para abrir en NetBeans
netbeans_project="/home/ismael/Escritorio/3 de INFO-ADE 1semestre/PDOO/Github/p3/Pr3/p2-java
"

# Abre la carpeta en Visual Studio Code
code "$vscode_project"

code "$vscode_project2"

# Abre la carpeta en NetBeans
netbeans "$netbeans_project"

carpeta="/home/ismael/Escritorio/3 de INFO-ADE 1semestre/PDOO/interpretaciondeDiagramas"

nautilus "$carpeta" &

firefox &
