/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;


/** 
 *
 * @author ismael
 */

/**
 * La clase {@code Game} representa el núcleo de la lógica de un juego, que incluye 
 * a los jugadores, monstruos, un laberinto y la gestión de rondas. 
 * Controla el estado actual del juego, el jugador que está en turno, 
 * y el registro de eventos.
 */
public class Game {
    
    /**
     * Número máximo de rondas que puede tener el juego.
     */
    private final int MAX_ROUNDS = 10;
    
    /**
     * Índice del jugador actual en el arreglo de jugadores.
     */
    int currentPlayerIndex;
    
    /**
     * Registro de los eventos que ocurren durante el juego.
     */
    String log;
    
    /**
     * Arreglo de jugadores que participan en el juego.
     */
    Player[] players;
    
    /**
     * Jugador que está tomando el turno actual.
     */
    Player currentPlayer;
    
    /**
     * Arreglo de monstruos que se encuentran en el juego.
     */
    Monster[] monsters;
    
    /**
     * Laberinto donde se desarrolla el juego.
     */
    Labyrinth lab;


    //¿como hago el constructor?
    //mi idea es  pasarle numeros de jug, monstruos, filas y columnas y ya inicialziarlo, pero que mas hago, uso spread?

    public Game(int nPlayers){
        // Inicializar el índice del jugador actual y el log
        this.currentPlayerIndex = Dice.whoStarts(nPlayers);
        this.log = "";

        
        // crear los jugadores y añadirlos al contenedor adecuado
        this.players = new Player[nPlayers];
        for (int i = 0; i < nPlayers; i++) {
            char c = (char) ('A' + i); // Convertir el índice en un carácter
            this.players[i] = new Player(c, Dice.randomIntelligence(), Dice.randomStrength());
        }
        
         currentPlayer = players[currentPlayerIndex];
         
        //Método que configura el laberinto
        configureLabyrinth();

        //Repartir jugadores por el laberinto
        lab.spreadPlayers(players);
    }

    public boolean finished(){
        return lab.haveAWinner();
    }

    /**
     * Genera una instancia de GameState integrando toda la información del
     * estado del juego.
     *
     * @return una instancia de GameState que representa el estado actual del juego.
     */
    public GameState getGameState(){
        return new GameState(lab.toString(), players.toString(), monsters.toString(), currentPlayerIndex,finished(), log);
    }

    /**
     * Configura el laberinto añadiendo bloques de obstáculos y monstruos.
     * Los monstruos, además de en el laberinto, son guardados en el contenedor propio de esta clase para
     * este tipo de objetos.
     */
    public void configureLabyrinth(){
        // Crear el laberinto
        lab  = new Labyrinth(10, 10, 9, 9);
        // Añadir bloques de obstáculos
        for (int i = 0; i < 5; i++) { // Añadir 5 bloques como ejemplo
            int startRow = Dice.randomPos(lab.getnRows()); // Genera una fila inicial aleatoria dentro del rango del laberinto
            int startCol = Dice.randomPos(lab.getnCols()); // Genera una columna inicial aleatoria dentro del rango del laberinto
            int length = Dice.randomPos(5) + 1; // Genera una longitud aleatoria para el bloque entre 1 y 5
            Orientation orientation = Dice.randomPos(2) == 0 ? Orientation.HORIZONTAL : Orientation.VERTICAL; // Determina aleatoriamente si el bloque será horizontal o vertical
            lab.addBlock(orientation, startRow, startCol, length); // Añade el bloque al laberinto en la posición y orientación especificadas
        }

        // Crear los monstruos (añadimos 3 monstruos como ejemplo)
        monsters = new Monster[3]; // Crear un arreglo de monstruos con 3 elementos
        for (int i = 0; i < monsters.length; i++) { // Iterar sobre cada monstruo en el arreglo de monstruos
            monsters[i] = new Monster("Monster " + (i + 1), Dice.randomIntelligence(), Dice.randomStrength()); // Crear un monstruo con nombre y atributos aleatorios
        }

        // Añadir monstruos
        for (Monster monster : monsters) { // Itera sobre cada monstruo en el arreglo de monstruos
            int[] pos = lab.randomEmptyPos(); // Encuentra una posición vacía aleatoria en el laberinto
            lab.addMonster(pos[0], pos[1], monster); // Añade el monstruo al laberinto en la posición encontrada
        }
    }

    /**
     * Actualiza los dos atributos que indican el jugador (current*) con el turno pasando
     * al siguiente jugador.
     */
    void nextPlayer(){
        currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
        currentPlayer = players[currentPlayerIndex];
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el jugador ha ganado el combate. También añade el indicador de 
     * nueva línea al final.
     */
    void logPlayerWon(){
        log += "Player " + currentPlayer.getNumber() + " won the combat.\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el monstruo ha ganado el combate. También añade el indicador de 
     * nueva línea al final.
     */
    void logMonsterWon(){
        log += "Monster won the combat against player " + currentPlayer.getNumber() + ".\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el jugador ha resucitado. También añade el indicador de nueva línea * al final.
     */
    void logResurrected(){
        log += "Player " + currentPlayer.getNumber() + " was resurrected.\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el jugador ha perdido el turno por estar muerto. También añade el indicador de nueva línea al final.
     */
    void logPlayerSkipTurn() {
        log += "Player " + currentPlayer.getNumber() + " skipped the turn because they are dead.\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el jugador no ha seguido las instrucciones del jugador humano (no fue posible).
     * También añade el indicador de nueva línea al final.
     */
    void logPlayerNoOrders() {
        log += "Player " + currentPlayer.getNumber() + " did not follow the human player's instructions.\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el mensaje
     * indicando que el jugador se ha movido a una celda vacía o no le ha sido posible moverse.
     * También añade el indicador de nueva línea al final.
     */
    void logNoMonster() {
        log += "Player " + currentPlayer.getNumber() + " moved to an empty cell or could not move.\n";
    }

    /**
     * Añade al final del atributo log (concatena cadena al final) el
     * mensaje que se han producido rounds de max rondas de combate. 
     * También añade el indicador de
     * nueva línea al final.
     */
    void logRounds(int rounds, int max) {
        log += "Rounds played: " + rounds + " out of " + max + ".\n";
    }

        boolean nextStep(Directions preferredDirection) {
        // Más información en la práctica 3
        throw new UnsupportedOperationException();
    }

    void actualDirection(Directions preferredDirection) {
        // Más información en la práctica 3
        throw new UnsupportedOperationException();
    }

    GameCharacter combat(Monster monster) {
        // Más información en la práctica 3
        throw new UnsupportedOperationException();
    }

    void manageReward(GameCharacter winner) {
        // Más información en la práctica 3
        throw new UnsupportedOperationException();
    }

    void manageResurrection() {
        // Más información en la práctica 3
        throw new UnsupportedOperationException();
    }
    


}





