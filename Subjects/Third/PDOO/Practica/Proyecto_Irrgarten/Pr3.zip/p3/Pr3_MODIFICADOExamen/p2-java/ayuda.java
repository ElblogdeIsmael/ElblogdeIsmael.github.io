private boolean hayBoostes;
private Weapon boostes;

public Weapon(float p, int u){
    this.power = p;
    this.uses = u;
    hayBoster = Dice.hayBustes()
    if(hayBoster){
        boostes = new Weapon(p,u);
    }
}


/*
 
Ahora en el attack pones que si hayBooster cuando lo uses bajes los usos del booster y el del propio weapon(este ya lo tienes) y cuando ataques el ataque sea la suma de los dos
 */