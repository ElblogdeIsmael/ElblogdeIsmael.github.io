require_relative 'Control/controller'
require_relative 'UI/textUI'
require_relative 'Game'

class Play
  def self.play
    text_ui = UI::TextUI.new
    game = Irrgarten::Game.new(2)
    controller = Control::Controller.new(game, text_ui)
    controller.play  # Inicia el juego con la interfaz de texto.
  end
end

Play.play if __FILE__ == $0


# debemos de generar este laberinto:
#   E - M -
#   - - - 0
#   - X X X
#   - M - -
#   - - - 1