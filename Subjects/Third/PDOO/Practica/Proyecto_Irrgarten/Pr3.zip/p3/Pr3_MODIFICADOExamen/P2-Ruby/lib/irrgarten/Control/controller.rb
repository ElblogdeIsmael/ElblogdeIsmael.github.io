module Control

  class Controller
    def initialize(game,view)
      @game = game
      @view = view
    end

    def play
      end_of_game = false
      #i = 0
      while (!end_of_game )# && i<22)
        @view.show_game(@game.getGameState) 
        direction = @view.next_move       #[i] si uso la otra forma
        end_of_game = @game.nextStep(direction)
        #puts "Secuencia de direcciones en la iteracion #{i} en dirección #{direction}"
        # i+=1
        
      end
      @view.show_game(@game.getGameState)
    end
  end # class   
end # module        

#solo he cambiado game_state por getGameState, que era como se llamaba en mis ficheros