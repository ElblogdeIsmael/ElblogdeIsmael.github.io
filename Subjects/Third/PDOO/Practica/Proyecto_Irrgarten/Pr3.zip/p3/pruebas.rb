class Coche
    @num = 0
    @@NUM_RUEDAS = 4
    @pepe=0
  
    def initialize(marca)
      @marca = marca
      Coche.increment
      @@NUM_RUEDAS = 10
    end
  
    def self.increment
      @num += 1
    end
  
    def self.num
      @num
    end
  
    def self.num_ruedas
      @@NUM_RUEDAS
    end

    def self.string
        puts "Si pinta esto es que puedes acceder a metodos de clase desde una instancia desde el main\n"
        @@NUM_RUEDAS = 100
    end
    
    def string
        puts "Esto es una prueba de método de instancia"
        @@NUM_RUEDAS = 200
        
    end 
  end
  
  # Código de prueba
  if __FILE__ == $0
    coche1 = Coche.new("Toyota")
    coche2 = Coche.new("Honda")
  
    puts "Número de coches creados: #{Coche.num}"
    puts "Número de ruedas por coche: #{Coche.num_ruedas}"
  
    Coche.increment
    puts "Número de coches (después de incremento manual): #{Coche.num}"

    coche1.string
    Coche.string
    coche1.string

    puts "Número de ruedas por coche: #{Coche.num_ruedas}"
  end
  