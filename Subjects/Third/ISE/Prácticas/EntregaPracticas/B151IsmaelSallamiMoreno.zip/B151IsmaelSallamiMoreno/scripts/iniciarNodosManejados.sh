#!/bin/bash

# Obtener el directorio donde se encuentra este script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Navegar un nivel arriba para llegar al directorio raíz del proyecto Ansible
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "====================================================================="
echo "Ejecutando Playbook de Iniciar Nodos Manejados (Apache/Nginx)"
echo "====================================================================="

ansible-playbook -i "${PROJECT_ROOT}/inventories/01_initial_setup_hosts.yaml" \
                 "${PROJECT_ROOT}/playbooks/01_initial_server_setup.yml" \
                 "$@" 
                        

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  echo "====================================================================="
  echo "Playbook de Iniciar Nodos Manejados completado con ÉXITO."
  echo "====================================================================="
else
  echo "====================================================================="
  echo "Playbook de Iniciar Nodos Manejados falló con código de error: $EXIT_CODE"
  echo "====================================================================="
fi

exit $EXIT_CODE