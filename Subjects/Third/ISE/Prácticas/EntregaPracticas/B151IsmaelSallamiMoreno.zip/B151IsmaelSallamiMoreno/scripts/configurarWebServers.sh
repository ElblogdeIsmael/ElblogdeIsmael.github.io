#!/bin/bash

# Script para ejecutar el playbook de configuración de servidores web (Apache/Nginx)

# Obtener el directorio donde se encuentra este script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Navegar un nivel arriba para llegar al directorio raíz del proyecto Ansible
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "====================================================================="
echo "Ejecutando Playbook de Configuración de Servidores Web (Apache/Nginx)"
# echo "Usando inventario: ${PROJECT_ROOT}/inventories/02_webservers_hosts.yaml"
# echo "Playbook: ${PROJECT_ROOT}/playbooks/02_configure_webservers.yml"
echo "====================================================================="

ansible-playbook -i "${PROJECT_ROOT}/inventories/02_webservers_hosts.yaml" \
                 "${PROJECT_ROOT}/playbooks/02_configure_webservers.yml" \
                 "$@" 
                        

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  echo "====================================================================="
  echo "Playbook de Servidores Web completado con ÉXITO."
  echo "====================================================================="
else
  echo "====================================================================="
  echo "Playbook de Servidores Web falló con código de error: $EXIT_CODE"
  echo "====================================================================="
fi

exit $EXIT_CODE