#!/bin/bash

echo "Esta directorio contiene dos archivos cpp con sus ejecutables de VARIOS CONSUMIDORES Y UN VARIOS PRODUCTORES"