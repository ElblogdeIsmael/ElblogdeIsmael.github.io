#!/bin/bash

echo "Esta directorio contiene EL PROBLEMA DE LOS FUMADORES resuelto en C++, se trata de que un estanquero proporciona uno de los ingredientes que les falta a los fumadores, y estos van fumando hasta que se les acaba el tabaco, papel o cerillas, entonces el estanquero les proporciona el ingrediente que les falta y vuelven a fumar, y así sucesivamente."