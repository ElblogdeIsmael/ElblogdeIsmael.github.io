#!/bin/bash

echo "Esta directorio contiene dos archivos cpp con sus ejecutables de UN SOLO CONSUMIDOR Y UN SOLO PRODUCTOR"