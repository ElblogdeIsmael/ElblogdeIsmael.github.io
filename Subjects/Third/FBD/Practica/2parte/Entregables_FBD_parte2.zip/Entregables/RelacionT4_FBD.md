# Relación Ejercicios T4

## Ejercicio 1

Explica por qué la organización de los registros en bloques es un elemento importante dentro del rendimiento de una base de datos.

La organización de registros en bloques es crucial porque las operaciones de E/S a disco son las más lentas. Agrupar los registros en bloques permite:
- Minimizar el número de accesos a disco, ya que se lee/escribe una unidad de datos (bloque) a la vez.
- Mejorar la eficiencia de la caché, pues los datos relacionados frecuentemente se encuentran en el mismo bloque.
- Optimizar las operaciones del SGBD que actúan sobre estas unidades mínimas de almacenamiento.


## Ejercicio 2
Disponemos de una base de datos sobre profesores, asignaturas e impartición de las mismas,
almacenada como muestran la Figura 1 y la Figura 2, usando un registro por página. Completa
la Figura 3 y la Figura 4 después haber realizado la siguiente secuencia de actualizaciones: Se
inserta la asignatura A7, se suprime el profesor P1, se eliminan las imparticiones del profesor
P1.

## Ejercicio 3

Dado que los índices agilizan el procesamiento de las consultas. ¿Por qué no se mantiene un
índice para cada campo del fichero? Enumera tantas razones como se te ocurran

## Ejercicio 4

Dado que los índices agilizan el procesamiento de las consultas. ¿Por qué no se mantiene un índice para cada campo del fichero? Enumera tantas razones como se te ocurran.

No se mantiene un índice para cada campo del fichero por las siguientes razones:

- Coste de almacenamiento adicional: Cada índice consume espacio en disco para sus propias estructuras de datos.

- Ralentización de las operaciones de actualización: Las operaciones de inserción, borrado y modificación de registros se vuelven más lentas porque cada índice afectado también debe actualizarse.

- Coste de mantenimiento del índice: Con el tiempo, los índices pueden necesitar reorganización para mantener su eficiencia, lo que consume recursos.

- Baja selectividad de algunos campos: Crear índices sobre campos con pocos valores distintos o que no se usan frecuentemente en condiciones de búsqueda ofrece poco beneficio y sí incurre en los costes mencionados.


## Ejercicio 5

¿Es posible tener dos índices primarios con diferentes claves sobre el mismo archivo almacenado?

## Ejercicio 5

¿Por qué es preferible utilizar un índice no-denso a uno denso? ¿Por qué no se utilizan índices no densos para todas las claves de búsqueda?

No, no es posible. Un índice primario se define sobre la clave física por la cual el fichero de datos está ordenado. Un archivo solo puede tener una única ordenación física a la vez.

<!-- Falta el ejercicio 6 y 7-->

## Ejercicio 8

¿Por qué una organización basada en el acceso directo no es la mejor idea para aquellos ficheros que se consulten por rangos de valores de la clave física (entre c1 y c2)?

Una organización basada en acceso directo (hashing) no es adecuada para consultas por rangos porque los algoritmos de direccionamiento no suelen mantener el orden de la clave. Los registros con claves secuenciales no se almacenan necesariamente en posiciones contiguas. Para buscar un rango, se tendría que aplicar la función hash a cada valor individual del rango o realizar un barrido completo del fichero, lo cual es ineficiente.

## Ejercicio 9

Enumera las ventajas e inconvenientes que tienen, a tu juicio, la organización basada en índices y la que se basa en el acceso directo. Haz un análisis comparativo.

### Organización Basada en Índices (ej. Árboles B+):

**Ventajas:**
- Eficiente para búsquedas exactas y por rango.
- Soporta la recuperación ordenada de datos.
- Flexibilidad para múltiples criterios de búsqueda mediante índices secundarios.

**Inconvenientes:**
- Coste de almacenamiento para los índices.
- Sobrecarga en operaciones de inserción, borrado y actualización debido al mantenimiento de los índices.

### Organización Basada en Acceso Directo (Hashing):

**Ventajas:**
- Potencialmente el acceso más rápido para búsquedas exactas (O(1) ideal).

**Inconvenientes:**
- Muy ineficiente para consultas por rango y recuperación ordenada.
- Problema de colisiones (claves diferentes mapean a la misma dirección).
- Posible desperdicio de espacio (huecos).
- La eficiencia depende de una buena función hash y de la distribución de las claves.
- Reorganizaciones costosas si el fichero crece mucho o las colisiones son excesivas (en hashing estático).

**Análisis Comparativo:**  
Los índices son más versátiles y ofrecen buen rendimiento para diversos tipos de consulta, incluyendo rangos y ordenación. El acceso directo es superior para búsquedas exactas ultra-rápidas donde la clave se conoce, pero es inflexible para otros tipos de consulta. La elección depende de los patrones de acceso predominantes.

## Ejercicio 10

Supongamos que se desea diseñar una estructura de hashing dinámico para un archivo que contiene los valores de clave:  
{2, 3, 4, 7, 11, 19, 23, 29, 31}  
Muestra la organización que se obtiene si la función de direccionamiento es f(x)=x mod 8 y las páginas pueden contener hasta tres registros (por cubo).

## Ejercicio 11

Muestra cómo cambia la estructura del ejercicio anterior como resultado de los siguientes pasos:  
a) Borrar el 11 y el 31  
b) Insertar el 1, el 15, el 36, el 40, el 46, el 25.

## Ejercicio 12

Supongamos que disponemos de una estructura de hashing dinámico que alberga hasta tres registros por página y que usa una función de dispersión f(x)=x mod 8.  
Dibuja la organización resultante después de:  
a) Insertar los registros con siguientes los valores para la clave:  
{12, 16, 19, 26, 29, 32, 35, 41, 44, 64}  
b) Eliminar de la anterior el registro con valor 32.  
c) Insertar sobre la estructura anterior los registros con siguientes los valores para la clave:  
{22, 39, 46, 55}


