/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 * La clase {@code Weapon} representa un arma en el juego que puede ser utilizada
 * por un jugador para atacar. Cada arma tiene un poder de ataque y un número
 * limitado de usos.
 * 
 * <p>Las armas se utilizan para infligir daño a los enemigos en el juego. Cada
 * vez que se usa un arma, el número de usos se decrementa y se aplica el poder
 * de ataque correspondiente.</p>
 * 
 * Atributos de la clase:
 * <ul>
 * <li><b>power:</b> El poder de ataque que tiene el arma.</li>
 * <li><b>uses:</b> El número de veces que el arma puede ser utilizada.</li>
 * </ul>
 * 
 * Métodos de la clase:
 * <ul>
 * <li><b>attack():</b> Realiza un ataque, devolviendo el poder de ataque del arma
 * y decrementando el número de usos.</li>
 * <li><b>toString():</b> Devuelve una representación en cadena del arma,
 * mostrando su poder y los usos restantes.</li>
 * <li><b>discard():</b> Determina si el arma debe ser descartada en función
 * de sus usos restantes.</li>
 * </ul>
 * 
 * @author ismael
 */
class Weapon {
    private float power; // El poder de ataque que tiene el arma.
    private int uses;    // El número de veces que el arma puede ser utilizada.

    /**
     * Constructor para crear un nuevo arma con un poder de ataque y un número de usos.
     *
     * @param power El poder de ataque del arma.
     * @param uses El número de usos disponibles para el arma.
     */
    public Weapon(float power, int uses) {
        this.power = power;
        this.uses = uses;
    }

    /**
     * Realiza un ataque con el arma. Si el arma tiene usos restantes,
     * decrementa el número de usos y devuelve el poder de ataque.
     *
     * @return El poder de ataque del arma si tiene usos restantes, 0 en caso contrario.
     */
    public float attack() {
        float n = 0;
        if (uses > 0) {
            uses--;
            n = power;
        }
        return n;
    }

    /**
     * Devuelve una representación en cadena del arma, mostrando
     * su poder de ataque y los usos restantes.
     *
     * @return Una cadena que representa el arma.
     */
    @Override
    public String toString() {
        String cad1 = Float.toString(power);
        String cad2 = String.valueOf(uses);
        return "W[" + cad1 + "," + cad2 + "]";
    }

    /**
     * Determina si el arma debe ser descartada en función de sus usos restantes.
     *
     * @return Verdadero si el arma debe ser descartada, falso en caso contrario.
     */
    public boolean discard() {
        return Dice.discardElement(uses);
    }
}