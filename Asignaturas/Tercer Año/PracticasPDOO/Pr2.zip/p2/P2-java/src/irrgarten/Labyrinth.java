/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */

/**
 * La clase {@code Labyrinth} representa un laberinto en el que se ubican jugadores y monstruos,
 * y donde los jugadores pueden moverse, combatir, y buscar la salida.
 * Proporciona funcionalidades para agregar monstruos, bloquear posiciones, y verificar 
 * la validez de movimientos en el laberinto.
 * 
 * <p>Contiene constantes para representar tipos de posiciones en el laberinto, 
 * así como métodos para gestionar y verificar el estado del laberinto.</p>
 * 
 * @author ismael
 */
public class Labyrinth {
    
    /**
     * Carácter que representa un bloque en el laberinto.
     */
    private final char BLOCK_CHAR = 'X';
    
    /**
     * Carácter que representa una posición vacía en el laberinto.
     */
    private final char EMPTY_CHAR = '-';
    
    /**
     * Carácter que representa la posición de un monstruo en el laberinto.
     */
    private final char MONSTER_CHAR = 'M';
    
    /**
     * Carácter que representa una posición de combate en el laberinto.
     */
    private final char COMBAT_CHAR = 'C';
    
    /**
     * Carácter que representa la salida del laberinto.
     */
    private final char EXIT_CHAR = 'E';
    
    /**
     * Constante que indica el índice de la fila.
     */
    private final int ROW = 0;
    
    /**
     * Constante que indica el índice de la columna.
     */
    private final int COL = 1;
    
    private int nRows;
    private int nCols;
    private int exitRow;
    private int exitCol;
    
    /**
     * Matriz que representa el laberinto con los diferentes tipos de posiciones.
     */
    private char labyrinth[][];
    
    /**
     * Matriz que contiene los monstruos ubicados en el laberinto.
     */
    private Monster monsters[][];
    
    /**
     * Matriz que contiene los jugadores ubicados en el laberinto.
     */
    private Player players[][];
    
    /**
     * Crea una nueva instancia de {@code Labyrinth} con las dimensiones y la posición de salida especificadas.
     *
     * @param nRows número de filas del laberinto
     * @param nCols número de columnas del laberinto
     * @param exitRow fila de la posición de salida
     * @param exitCol columna de la posición de salida
     */
    public Labyrinth(int nRows, int nCols, int exitRow, int exitCol) {
        this.nRows = nRows;
        this.nCols = nCols;
        this.exitRow = exitRow;
        this.exitCol = exitCol;
        labyrinth = new char[nRows][nCols];
        for(int i=0;i<nRows;i++){ //inicializamos la matriz a casillas vacias
            for(int j=0;j<nCols;j++){
                labyrinth[i][j]=EMPTY_CHAR;
            }
        }
        labyrinth[exitRow][exitCol]=EXIT_CHAR;
        monsters = new Monster[nRows][nCols];
        players = new Player[nRows][nCols];
    }

    // Getters y Setters

    /**
     * Obtiene el número de filas del laberinto.
     *
     * @return el número de filas
     */
    public int getnRows() {
        return nRows;
    }

    /**
     * Establece el número de filas del laberinto.
     *
     * @param nRows el número de filas
     */
    public void setnRows(int nRows) {
        this.nRows = nRows;
    }

    /**
     * Obtiene el número de columnas del laberinto.
     *
     * @return el número de columnas
     */
    public int getnCols() {
        return nCols;
    }

    /**
     * Establece el número de columnas del laberinto.
     *
     * @param nCols el número de columnas
     */
    public void setnCols(int nCols) {
        this.nCols = nCols;
    }

    /**
     * Distribuye los jugadores en el laberinto.
     *
     * @param players arreglo de jugadores a ubicar en el laberinto
     */
    public void spreadPlayers(Player players[]) {
        throw new UnsupportedOperationException();
    }

    /**
     * Verifica si algún jugador ha alcanzado la salida, indicando que hay un ganador.
     *
     * @return {@code true} si hay un jugador en la salida; {@code false} de lo contrario
     */
    public boolean haveAWinner() {
        return players[exitRow][exitCol] != null;
    }

    /**
     * Devuelve una representación en cadena del estado del laberinto.
     *
     * @return una cadena que incluye las dimensiones y la posición de salida del laberinto
     */
    public String toString() {
        return "nRows: " + nRows + " nCols: " + nCols + " exitRow: " + exitRow + " exitCol: " + exitCol;
    }

    /**
     * Agrega un monstruo en la posición especificada si está vacía.
     *
     * @param row la fila en la que se ubicará el monstruo
     * @param col la columna en la que se ubicará el monstruo
     * @param monster el monstruo a agregar
     */
    public void addMonster(int row, int col, Monster monster) {
        if (emptyPos(row,col)) {
            labyrinth[row][col] = MONSTER_CHAR;
            monster.setPos(row, col);
            monsters[row][col]=monster;
        }
    }

    /**
     * Verifica si una posición en el laberinto es válida.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición es válida; {@code false} de lo contrario
     */
    public boolean posOK(int row, int col) {
        return row >= 0 && row < nRows && col >= 0 && col < nCols;
    }

    /**
     * Verifica si una posición está vacía.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición está vacía; {@code false} de lo contrario
     */
    public boolean emptyPos(int row, int col) {
        return posOK(row, col) &&  labyrinth[row][col] == EMPTY_CHAR ;
    }

    /**
     * Verifica si hay un monstruo en la posición especificada.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición contiene un monstruo; {@code false} de lo contrario
     */
    public boolean monsterPos(int row, int col) {
        return posOK(row, col) && labyrinth[row][col]==MONSTER_CHAR;
    }

    /**
     * Verifica si la posición especificada es la salida del laberinto.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición es la salida; {@code false} de lo contrario
     */
    public boolean exitPos(int row, int col) {
        return posOK(row, col) && labyrinth[row][col]==EXIT_CHAR;
    }

    /**
     * Verifica si una posición es una posición de combate.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición es de combate; {@code false} de lo contrario
     */
    public boolean combatPos(int row, int col) {
        return posOK(row, col) && labyrinth[row][col]==COMBAT_CHAR;
    }

    /**
     * Verifica si es posible moverse a una posición específica.
     *
     * @param row la fila de la posición
     * @param col la columna de la posición
     * @return {@code true} si la posición es válida y se puede pisar; {@code false} de lo contrario
     */
    public boolean canStepOn(int row, int col) {
        return posOK(row, col) && (emptyPos(row, col) || monsterPos(row, col) || exitPos(row, col));
    }

    /**
     * Actualiza la posición anterior de un jugador en el laberinto.
     *
     * @param row la fila de la posición anterior
     * @param col la columna de la posición anterior
     */
    public void updateOldPos(int row, int col) {
        if (posOK(row, col)) {
            labyrinth[row][col] = (labyrinth[row][col] == COMBAT_CHAR) ? MONSTER_CHAR : EMPTY_CHAR;
            players[row][col] = null;
        }
    }
    
    /**
     * Ajusta la posición (fila, columna) basada en la dirección dada.
     *
     * @param row       la posición actual de la fila
     * @param col       la posición actual de la columna
     * @param direction la dirección en la que se desea mover ("UP", "DOWN", "RIGHT", "LEFT")
     * @return un arreglo de enteros donde el primer elemento es la nueva posición de la fila
     *         y el segundo elemento es la nueva posición de la columna
     */
    public int[] dir2Pos(int row, int col, Directions direction) {
        int[] pos = new int[2];
        switch (direction) {
            case UP:
                pos[ROW] = row - 1;
                pos[COL] = col;
                break;
            case DOWN:
                pos[ROW] = row + 1;
                pos[COL] = col;
                break;
            case RIGHT:
                pos[ROW] = row;
                pos[COL] = col + 1;
                break;
            case LEFT:
                pos[ROW] = row;
                pos[COL] = col - 1;
                break;
        }
        return pos;
    }

        
    /**
     * Devuelve una posición aleatoria en el laberinto que esté vacía.
     *
     * @return un arreglo de enteros que representa la posición vacía [fila, columna]
     */
    public int[] randomEmptyPos() {
        int[] pos = new int[2];
        while (true) {
            pos[ROW] = Dice.randomPos(nRows);
            pos[COL] = Dice.randomPos(nCols);
            if (emptyPos(pos[0], pos[1])) {
                break;
            }
        }
        return pos;
    }

    public Monster putPlayer2D(int oldRow, int oldCol, int row, int col, Player player) {
        throw new UnsupportedOperationException();
    }

    public Monster putPlayer(Directions direction, Player player) {
        throw new UnsupportedOperationException();
    }
    
    public void addBlock(Orientation orientation, int startRow, int startCol, int length) {
        throw new UnsupportedOperationException();
    }
    
    public Directions[] validMoves(int row, int col) {
        throw new UnsupportedOperationException();
    }
    /**
     * Añade un jugador en la casilla que se indica.
     * @param row fila de la casilla
     * @param col columna de la casilla
     * @param player jugador a añadir
     */
    public void addPlayer(int row, int col, Player player) {
        if(emptyPos(row, col)) {
            labyrinth[row][col] = player.getCharNumber();
            player.setPos(row, col);
            players[row][col] = player;
        }
    }
    
    /**
     * Funcion que me diga donde hay monstruos y jugadores 
     */
    public void showMonstersAndPlayers() {
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nCols; j++) {
                if(monsterPos(i, j)) {
                    System.out.println("Hay un monstruo en la posición: " + i + ", " + j);
                }
                if(players[i][j] != null) {
                    System.out.println("Hay un jugador en la posición: " + i + ", " + j);
                }
            }
        }
    }
    
    /**
     * Añadir casilla de combate
     * @param row fila de la casilla
     * @param col columna de la casilla
     */
    public void addCombat(int row, int col) {
        labyrinth[row][col] = COMBAT_CHAR;
    }
    
    /**
     * Funcion que me dice en que casillas hay combate
     */
    public void showCombat() {
        for(int i = 0; i < nRows; i++) {
            for(int j = 0; j < nCols; j++) {
                if(combatPos(i, j)) {
                    System.out.println("Hay combate en la posición: " + i + ", " + j);
                }
            }
        }
    }

}
