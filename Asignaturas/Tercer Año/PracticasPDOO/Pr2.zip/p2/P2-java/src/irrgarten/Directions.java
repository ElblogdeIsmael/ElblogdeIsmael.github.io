/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */

/**
 * La enumeración {@code Directions} define las direcciones básicas de movimiento 
 * en un entorno bidimensional.
 * 
 * <p>Las direcciones posibles son:</p>
 * <ul>
 *   <li>{@link #LEFT} - Movimiento hacia la izquierda</li>
 *   <li>{@link #RIGHT} - Movimiento hacia la derecha</li>
 *   <li>{@link #UP} - Movimiento hacia arriba</li>
 *   <li>{@link #DOWN} - Movimiento hacia abajo</li>
 * </ul>
 */
public enum Directions {
    /**
     * Movimiento hacia la izquierda.
     */
    LEFT,
    
    /**
     * Movimiento hacia la derecha.
     */
    RIGHT,
    
    /**
     * Movimiento hacia arriba.
     */
    UP,
    
    /**
     * Movimiento hacia abajo.
     */
    DOWN
}
