#encoding:utf-8

# Módulo principal del juego Irrgarten, que contiene las clases de jugadores y otros elementos.
module Irrgarten 
    # Representa un jugador en el juego con atributos de salud, posición, fuerza, y defensas.
    class Player
        # Número máximo de armas que un jugador puede llevar.
        MAX_WEAPONS = 2

        # Número máximo de escudos que un jugador puede llevar.
        MAX_SHIELDS = 3

        # Salud inicial con la que un jugador comienza o es resucitado.
        INITIAL_HEALTH = 10

        # Cantidad de golpes consecutivos necesarios para perder la partida.
        HITS2LOSE = 3

        # @!attribute [rw] name
        #   @return [String] El nombre del jugador.
        attr_accessor :name

        # @!attribute [rw] number
        #   @return [Integer] El número de identificación del jugador.
        attr_accessor :number

        # @!attribute [rw] intelligence
        #   @return [Integer] La inteligencia del jugador.
        attr_accessor :intelligence

        # @!attribute [rw] strength
        #   @return [Integer] La fuerza del jugador.
        attr_accessor :strength

        # @!attribute [rw] health
        #   @return [Integer] La salud actual del jugador.
        attr_accessor :health

        # @!attribute [rw] row
        #   @return [Integer] La fila de la posición actual del jugador.
        attr_accessor :row

        # @!attribute [rw] col
        #   @return [Integer] La columna de la posición actual del jugador.
        attr_accessor :col

        # @!attribute [rw] consecutiveHits
        #   @return [Integer] El contador de golpes consecutivos que ha recibido el jugador.
        attr_accessor :consecutiveHits

        # @!attribute [rw] weapons
        #   @return [Array<Weapon>] Arreglo de armas que posee el jugador.
        attr_accessor :weapons

        # @!attribute [rw] shields
        #   @return [Array<Shield>] Arreglo de escudos que posee el jugador.
        attr_accessor :shields

        # Inicializa un nuevo jugador con los atributos básicos de nombre, número, inteligencia y fuerza.
        #
        # @param number [Integer] El número de identificación del jugador.
        # @param intelligence [Integer] La inteligencia del jugador.
        # @param strength [Integer] La fuerza del jugador.
        def initialize(number, intelligence, strength)
            @name = "Player#{number}"+-
            @number = number
            @intelligence = intelligence
            @strength = strength
            @health = INITIAL_HEALTH
            @row = -1
            @col = -1
            @consecutiveHits = 0
            @weapons = Array.new
            @shields = Array.new

        end 

        # Resucita al jugador, restaurando su salud inicial y reiniciando sus armas y escudos.
        #
        # @return [void]
        def resurrect 
            @health = INITIAL_HEALTH
            @consecutiveHits = 0
            @weapons = Array.new
            @shields = Array.new
        end

        # Establece la posición del jugador en una fila y columna específicas.
        #
        # @param row [Integer] La fila de la posición.
        # @param col [Integer] La columna de la posición.
        # @return [void]
        def setPos(row, col)
            @row = row
            @col = col
        end

        # Verifica si el jugador está muerto (salud <= 0).
        #
        # @return [Boolean] `true` si la salud es 0 o menor, `false` en caso contrario.
        def dead 
            return @health <= 0
        end

        # Realiza un ataque utilizando la fuerza del jugador y el poder de sus armas.
        #
        # @return [Integer] La intensidad del ataque.
        def attack
            return @strength + sumWeapons
        end

        # Gestiona la defensa del jugador contra un ataque recibido.
        #
        # @param receivedAttack [Integer] El valor del ataque recibido.
        # @return [Integer] El resultado de la gestión del ataque.
        def defend(receivedAttack)
            return manageHits(receivedAttack)
        end

        # Convierte el estado del jugador en un string para representación.
        #
        # @return [String] La representación del jugador en formato `P[nombre, inteligencia, fuerza, salud, fila, columna]`.
        def toString
            return "Player[#{@name}, #{@intelligence}, #{@strength}, #{@health}, #{@row}, #{@col}]"
        end

        # Crea una nueva arma con poder y usos restantes aleatorios.
        #
        # @return [Weapon] La nueva arma generada.
        def newWeapon
            w = Weapon.new(Dice.weaponPower, Dice.usesLeft)
            return w 
        end

        # Crea un nuevo escudo con poder defensivo aleatorio.
        #
        # @return [Shield] El nuevo escudo generado.
        def newShield
            s = Shield.new(Dice.shieldPower, Dice.usesLeft)
            return s
        end

        # Calcula la energía defensiva total del jugador sumando el poder de todos sus escudos.
        #
        # @return [Integer] La energía defensiva total.
        def defensiveEnergy
            return @intelligence + sumShields
        end

        # Reinicia el contador de golpes consecutivos del jugador.
        #
        # @return [void]
        def resetsHits
            @consecutiveHits = 0
        end

        # Reduce la salud del jugador en 1 punto, indicando que ha sido herido.
        #
        # @return [void]
        def gotWounded
            @health = @health - 1
        end

        # Incrementa el contador de golpes consecutivos del jugador en 1.
        #
        # @return [void]
        def incConsecutiveHits
            @consecutiveHits += 1
        end

        # Suma el poder de ataque de todas las armas del jugador.
        #
        # @return [Integer] La suma del poder de todas las armas.
        def sumWeapons 
            sum = 0
            @weapons.each do |w|
                sum += w.attack
            end
            return sum
        end

        # Suma la energía defensiva de todos los escudos del jugador.
        #
        # @return [Integer] La suma de la energía defensiva de todos los escudos.
        def sumShields 
            sum = 0
            @shields.each do |s|
                sum += s.protect
            end
            return sum
        end
        
        # métodos de la práctica 3

        # def move(directions, validMoves) 
        # end
        
        # def receiveReward
        # end

        # def receiveWeapon(w)
        # end

        # def receiveShield(s)
        # end

        # def boolean manageHits(receivedAttack)
        # end

        #añade una nueva arma
        #
        # @param weapon [Weapon] La nueva arma a añadir.
        def addWeapon(weapon)
            @weapons.push(weapon)
        end

        #añade un nuevo escudo
        #
        # @param shield [Shield] El nuevo escudo a añadir.
        def addShield(shield)
            @shields.push(shield)
        end


    end
end