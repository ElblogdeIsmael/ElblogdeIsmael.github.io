#include <cassert>
#include <thread>
#include <mutex>
#include <random> // dispositivos, generadores y distribuciones aleatorias
#include <chrono> // duraciones (duration), unidades de tiempo
#include "scd.h"

using namespace std ;
using namespace scd ;

const int num_fumadores = 3 ;

//declaramos los semáforos
Semaphore sem_fumadores[num_fumadores] = {0,0,0}; // 1 si el ingrediente esta en el mostrador, 0 si no esta
Semaphore mostrador_vacio = 1; // 1 si el mostrador esta vacio, 0 si esta lleno, inicialmente esta vacio

//funcion de producirIngrediente

int producirIngrediente()
{
   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_produ( aleatorio<10,100>() );

   // informa de que comienza a producir
   cout << "Estanquero : empieza a producir ingrediente (" << duracion_produ.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_produ' milisegundos
   this_thread::sleep_for( duracion_produ );

   const int num_ingrediente = aleatorio<0,num_fumadores-1>() ;

   // informa de que ha terminado de producir
   cout << "Estanquero : termina de producir ingrediente " << num_ingrediente << endl;

   return num_ingrediente ;
}

//funcion que ejeuta el estanquero
void funcion_hebra_estanquero() {
    while(true){
        int ingrediente = producirIngrediente();
        mostrador_vacio.sem_wait();
        //reducimos el valor del semaforo a 0 y llevamos la hebra a que espere en la cola del mostrador, debido a que ya hay un ingrediente en el mismo
        sem_fumadores[ingrediente].sem_signal();
        //despertamos al fumador que necesita el ingrediente producido y que esta en la cola de dicho semaforo
    }
}

//funcion que simula la accion de fumar
void fumar( int num_fumador )
{

   // calcular milisegundos aleatorios de duración de la acción de fumar)
   chrono::milliseconds duracion_fumar( aleatorio<20,200>() );

   // informa de que comienza a fumar

   cout << "Fumador " << num_fumador << "  :"
         << " empieza a fumar (" << duracion_fumar.count() << " milisegundos)" << endl;

   // espera bloqueada un tiempo igual a ''duracion_fumar' milisegundos
   this_thread::sleep_for( duracion_fumar );

   // informa de que ha terminado de fumar

   cout << "Fumador " << num_fumador << "  : termina de fumar, comienza espera de ingrediente." << endl;

}

//funcion que ejecuta la hebra del fumador
void funcion_hebra_fumador(int num_fumador){
    while(true){
        sem_fumadores[num_fumador].sem_wait();
        //reducimos el valor del semaforo a 0 y llevamos la hebra a que espere en la cola del semaforo, debido a que no hay un ingrediente en el mostrador porque este ya lo ha cogido, y a continuación indicamos que el mostrador debe de producir un nuevo ingrediente
        mostrador_vacio.sem_signal();
        //despertamos al estanquero para que produzca un nuevo ingrediente
        fumar(num_fumador);
    }
}

int main(){
    vector<thread> hebra_fumadores;
    thread hebra_estanquero(funcion_hebra_estanquero);

    for(int i = 0; i < num_fumadores; i++){
        hebra_fumadores.push_back(thread(funcion_hebra_fumador, i));
    }
    hebra_estanquero.join();
    for(int i = 0; i < num_fumadores; i++){
        hebra_fumadores[i].join();
    }
    return 0;
}