#include <thread>
#include <random>
#include <vector>
#include "scd.h"

using namespace std;
using namespace scd;

const unsigned num_items = 40;    // número total de ítems a producir/consumir
const unsigned tam_buffer = 10;      // tamaño del buffer compartido

//numero de hebras productoras y consumidoras
const int np = 4;                 // número de hebras productoras
const int nc = 2;                 // número de hebras consumidoras

const int p = num_items / np;      // ítems que produce cada productor
const int c = num_items / nc;      // ítems que consume cada consumidor

int buffer[tam_buffer];              // buffer de datos compartido

int primera_libre = 0;       // índice de la primera celda libre del buffer, siguiendo el método LIFO
int primera_ocupada = 0;     // índice del primer dato ocupado en el buffer, siguiendo el método LIFO

unsigned cont_prod[num_items] = {0},    // array que guarda cuántos ítems ha producido cada productor
cont_cons[num_items] = {0}; // contadores para verificar consumo de cada dato

unsigned cuentas[np] = {0}; //contador para saber cuantos datos ha producido cada productor

Semaphore libres(tam_buffer);        // semáforo que cuenta los huecos libres en el buffer
Semaphore ocupadas(0);            // semáforo que cuenta los ítems disponibles en el buffer

mutex mtx; //mutex para la sección crítica y para garantizar la exclusión mutua



// Función para producir un dato (simula la producción de datos)


unsigned producir_dato(int num_hebra){
    unsigned dato_producido = num_hebra * p + cont_prod[num_hebra];//el dato que vamos a producir es, por ejemplo, si tenemos 40 datos y 4 productores, el productor 0 producirá los datos 0, 1,2, .... hasta 9, debido a que cada productor debe de producir 10 elementos, por lo que si num_hebra vale 0 y hemos producido solo un dato de esa hebra, el resultado será: 0*10 + 1 = 1, por lo que el dato producido será 1, ya que anteriormente hemos producido el 0
    cont_prod[num_hebra]++; //incrementamos el contador de la producción del dato
    this_thread::sleep_for(chrono::milliseconds(aleatorio<20, 100>())); //simulamos la producción de un dato
    cout << "Productor " << num_hebra << " ha producido: " << dato_producido << endl; //mostramos por pantalla el dato que ha producido
    return dato_producido; //devolvemos el dato producido
}

// Función para consumir un dato (simula el consumo de datos)

void consumir_dato(unsigned dato, int num_hebra){
    assert(dato < num_items); //comprobamos que el dato que vamos a consumir sea menor que el número total de datos
    cont_cons[dato]++; //incrementamos el contador de consumos del dato
    this_thread::sleep_for(chrono::milliseconds(aleatorio<20, 100>())); //simulamos el consumo de un dato
    cout << "Consumidor " << num_hebra << " ha consumido: " << dato << endl; //mostramos por pantalla el dato que ha consumido
}
//NO SE IMPONE  LA CONDICIÓN DE QUE LOS CONSUMIDORES DEBAN DE CONSUMIR EL MISMO NÚMERO DE DATOS 

// Función que ejecuta la hebra productora (LIFO)

void funcion_hebra_productora(int num_hebra){
    for(int i=0;i<p;i++){
        unsigned dato = producir_dato(num_hebra); //producimos un dato
        libres.sem_wait(); //decrementamos libres y añadimos a la cola de espera de libres una hebra
        mtx.lock(); //bloqueamos el acceso a la sección crítica, ya que primera_libre es una variable compartida
        buffer[primera_libre] = dato; //colocamos el dato en el buffer
        primera_libre = (primera_libre + 1) % tam_buffer; //
        mtx.unlock(); //desbloqueamos el acceso a la sección crítica
        ocupadas.sem_signal(); //incrementamos ocupadas y sacamos a una hebra de la cola de espera de ocupadas para que lea el dato
    }
}

// Función que ejecuta la hebra consumidora (LIFO)

void funcion_hebra_consumidora(int num_hebra){
    for (int i = 0; i < c; i++)
    {
        ocupadas.sem_wait(); //decrementamos el valor de ocupadas debido a que una hebra puede consumir el valor y a la vez la añadimos a la cola de ocupadas, ya que en este sentido, esta ocupada consumiendo el valor
        mtx.lock(); //bloqueamos el acceso a la sección crítica, ya que primera_libre es una variable compartida
        unsigned dato = buffer[primera_ocupada]; //consumimos el dato
        primera_ocupada = (primera_ocupada + 1) % tam_buffer; //actualizamos el índice de ocupado
        mtx.unlock(); //desbloqueamos el acceso a la sección crítica
        libres.sem_signal(); //incrementamos el valor de libres y sacamos a una hebra de la cola de espera de libres para que pueda producir un dato, ya que en este momento hay un hueco libre
        consumir_dato(dato, num_hebra); //consumimos el dato
    }
}

void test_contadores() {
    bool correcto = true;
    cout << "Comprobando contadores..." << endl;
    for (unsigned i = 0; i < num_items; i++) {
        if (cont_prod[i % np] != p) {
            cout << "Error: Hebra productora " << (i % np) << " ha producido incorrectamente." << endl;
            correcto = false;
        }
        if (cont_cons[i] != 1) {
            cout << "Error: Dato " << i << " consumido " << cont_cons[i] << " veces." << endl;
            correcto = false;
        }
    }
    if (correcto) {
        cout << "Solución correcta." << endl;
    }
}

int main(){
    cout << "Problema de los productores-consumidores (solución con semáforos, múltiples hebras) SOLUCIÓN LIFO." << endl;
    vector<thread> hebras_productores;
    vector<thread> hebras_consumidores;
    for(int i=0;i<np;i++){
        hebras_productores.push_back(thread(funcion_hebra_productora,i));
    }
    for(int i=0;i<nc;i++){
        hebras_consumidores.push_back(thread(funcion_hebra_consumidora,i));
    }
    for(int i=0;i<np;i++){
        hebras_productores[i].join();
    }
    for(int i=0;i<nc;i++){
        hebras_consumidores[i].join();
    }
    test_contadores();
    return 0;
}
    
