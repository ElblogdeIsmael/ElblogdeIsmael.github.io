#include <iostream>
#include <cassert>
#include <thread>
#include <mutex>
#include <random>
#include "scd.h"

using namespace std ;
using namespace scd ;

//VARIABLES GLOBALES

const unsigned
    num_items = 40, //numero de items
    tam_buffer = 10; //tamaño del buffer

unsigned
    cont_prod[num_items] = {0}, // contadores de verificación: para cada dato, número de veces que se ha producido.
    cont_cons[num_items] = {0}, // contadores de verificación: para cada dato, número de veces que se ha consumido.
    siguiente_dato       = 0 ;  // siguiente dato a producir en 'producir_dato' (solo se usa ahí)

int primera_libre = 0; //seguimos el proceso de la solución LIFO
int primera_ocupada = 0; //seguimos el proceso de la solución FIFO e inicialmente no hay nada ocupado
//buffer de datos compartido
vector<unsigned> buffer(tam_buffer);

//Semáforos
Semaphore libres=tam_buffer;
/*  
El semáforo libres posee:
    - lista de procesos bloqueados en la cola de espera, inicialmente vacía
    - contador de recursos libres, inicializado a tam_buffer
*/

Semaphore ocupadas=0;
/*
El semáforo ocupadas posee:
    - lista de procesos bloqueados en la cola de espera, inicialmente vacía
    - contador de recursos ocupados, inicializado a 0
*/

mutex mtx; //para controlar la Exclusión Mutua


// funciones comunes a las dos soluciones (fifo y lifo)

unsigned producir_dato(){
    this_thread::sleep_for( chrono::milliseconds(aleatorio<20,100>() ));
    const unsigned dato_producido = siguiente_dato;
    siguiente_dato++;
    cont_prod[dato_producido]++;
    mtx.lock();
    cout << "producido: " << dato_producido << endl << flush;
    mtx.unlock();
    return dato_producido;
}

void consumir_dato(unsigned dato){
    assert(dato < num_items);
    cont_cons[dato]++;
    this_thread::sleep_for( chrono::milliseconds(aleatorio<20,100>() ));
    mtx.lock();
    cout << "dato consumido: " << dato << endl;
    mtx.unlock();
}

void test_contadores()
{
    bool ok = true ;
    mtx.lock() ;
    cout << "comprobando contadores ...." ;
    mtx.unlock() ;
    for( unsigned i = 0 ; i < num_items ; i++ )
    {  if ( cont_prod[i] != 1 ){
            cout << "error: valor " << i << " producido " << cont_prod[i] << " veces." << endl ;
            ok = false ;
        }
        if ( cont_cons[i] != 1 )
        {  cout << "error: valor " << i << " consumido " << cont_cons[i] << " veces" << endl ;
            ok = false ;
        }
    }
    if (ok)
        cout << endl << flush << "solución (aparentemente) correcta." << endl << flush ;
}


//funciones de la hebra productora y consumidora

void funcion_hebra_productora(){
    for(int i = 0; i <num_items; i++){
        int dato = producir_dato();
        //hemos producido un dato, por lo que debemos de hacer un wait a libres
        //¿porque no un signal a ocupadas? Porque debemos de parar a las hebras productoras en 1, ya que disponemos de una posición menos del buffer
        libres.sem_wait();
        //actualizamos el buffer, pero al ser una variable compartida debemos de usar el mutex para protegerla de las demás hebras
        mtx.lock();
        buffer[primera_libre] = dato;
        primera_libre = (primera_libre + 1) % tam_buffer;
        //seguimos el esquema de LIFO
        mtx.unlock();
        //ahora como ya hay un producto, podemos despertar a 1 consumidor:
        ocupadas.sem_signal();
    }

}

void funcion_hebra_consumidora(){
    for (int i = 0; i < num_items; i++)
    {
        int dato;
        //debemos de decirle a uno de los productores que se detenga para poder consumirlo
        ocupadas.sem_wait();
        dato = buffer[primera_ocupada];
        primera_ocupada = (primera_ocupada + 1) % tam_buffer;
        //al consumir un dato debemos dejamos un sitio libre en el buffer, por lo que podemos despertar uno de los productores que se encuentre esperando en la cola de la variable condicional libres
        libres.sem_signal();
        consumir_dato(dato);
    }
    
}

int main(){
    cout << "-----------------------------------------------------------------" << endl
    << "Problema de los productores-consumidores (solución FIFO)." << endl
    << "------------------------------------------------------------------" << endl
    << flush ;

    thread hebra_productora(funcion_hebra_productora);
    thread hebra_consumidora(funcion_hebra_consumidora);
    hebra_productora.join();
    hebra_consumidora.join();
    test_contadores();
    return 0;
}